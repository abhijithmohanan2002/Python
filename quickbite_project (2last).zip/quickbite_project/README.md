# QuickBite (Django) - Quick start

1. Create virtualenv and install requirements

   python -m venv venv
   source venv/bin/activate    # on Windows: venv\Scripts\activate
   pip install -r requirements.txt

2. Run migrations

   python manage.py makemigrations
   python manage.py migrate

3. Create superuser

   python manage.py createsuperuser

4. Run server

   python manage.py runserver

5. Open http://127.0.0.1:8000/
