from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone


class CustomUser(AbstractUser):
    STUDENT = 'STUDENT'
    STAFF = 'STAFF'
    ADMIN = 'ADMIN'
    ROLE_CHOICES = [
        (STUDENT, 'Student'),
        (STAFF, 'Staff'),
        (ADMIN, 'Admin'),
    ]

    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=STUDENT)

    def is_student(self):
        return self.role == self.STUDENT

    def is_staff_user(self):
        return self.role == self.STAFF

    def is_admin_user(self):
        return self.role == self.ADMIN


class TimeSlot(models.Model):
    name = models.CharField(max_length=50)
    start_time = models.TimeField()
    end_time = models.TimeField()

    def __str__(self):
        return f"{self.name} ({self.start_time.strftime('%H:%M')}-{self.end_time.strftime('%H:%M')})"


class MenuItem(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=7, decimal_places=2)
    available = models.BooleanField(default=True)
    stock = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.name} - ₹{self.price}"


class Order(models.Model):
    PENDING = 'PENDING'
    PREPARING = 'PREPARING'
    READY = 'READY'
    COMPLETED = 'COMPLETED'
    STATUS_CHOICES = [
        (PENDING, 'Pending'),
        (PREPARING, 'Preparing'),
        (READY, 'Ready'),
        (COMPLETED, 'Completed'),
    ]

    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    created_at = models.DateTimeField(default=timezone.now)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=PENDING)
    token = models.PositiveIntegerField(null=True, blank=True)
    timeslot = models.ForeignKey(TimeSlot, on_delete=models.SET_NULL, null=True, blank=True)
    total_amount = models.DecimalField(max_digits=9, decimal_places=2, default=0)

    def __str__(self):
        return f"Order #{self.id} by {self.user.username} - {self.status}"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    menu_item = models.ForeignKey(MenuItem, on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(default=1)
    price = models.DecimalField(max_digits=7, decimal_places=2)

    def line_total(self):
        return self.quantity * self.price

    def __str__(self):
        return f"{self.quantity} x {self.menu_item.name}"


class InventoryLog(models.Model):
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    change = models.IntegerField()
    note = models.CharField(max_length=255, blank=True)
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.menu_item.name}: {self.change} at {self.timestamp}"
