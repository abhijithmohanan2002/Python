from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.http import HttpResponse
from .forms import StudentSignUpForm
from .models import MenuItem, Order, OrderItem, TimeSlot, CustomUser
from django.db import transaction
from decimal import Decimal

def home(request):
    return redirect('canteen:menu')

def register(request):
    if request.method == 'POST':
        form = StudentSignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('canteen:menu')
    else:
        form = StudentSignUpForm()
    return render(request, 'canteen/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            if user.role == CustomUser.STAFF:
                return redirect('canteen:staff_dashboard')
            return redirect('canteen:menu')
    else:
        form = AuthenticationForm()
    return render(request, 'canteen/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('canteen:menu')

@login_required
def menu(request):
    items = MenuItem.objects.filter(available=True)
    timeslots = TimeSlot.objects.all()
    return render(request, 'canteen/menu.html', {'items': items, 'timeslots': timeslots})

@login_required
def cart_view(request):
    cart = request.session.get('cart', {})
    items = []
    total = Decimal('0')
    for item_id, qty in cart.items():
        mi = MenuItem.objects.get(pk=item_id)
        items.append({'item': mi, 'qty': qty, 'subtotal': mi.price * qty})
        total += mi.price * qty
    return render(request, 'canteen/cart.html', {'cart_items': items, 'total': total})

@login_required
@transaction.atomic
def checkout(request):
    if request.method == 'POST':
        cart = request.session.get('cart', {})
        timeslot_id = request.POST.get('timeslot')
        timeslot = TimeSlot.objects.filter(pk=timeslot_id).first()
        if not cart:
            return HttpResponse('Cart empty', status=400)
        order = Order.objects.create(user=request.user, timeslot=timeslot)
        total = Decimal('0')
        token_base = Order.objects.count() + 1000
        order.token = token_base
        for item_id, qty in cart.items():
            mi = MenuItem.objects.select_for_update().get(pk=item_id)
            if mi.stock < int(qty):
                transaction.set_rollback(True)
                return HttpResponse(f'Not enough stock for {mi.name}', status=400)
            mi.stock -= int(qty)
            mi.save()
            OrderItem.objects.create(order=order, menu_item=mi, quantity=qty, price=mi.price)
            total += mi.price * int(qty)
        order.total_amount = total
        order.save()
        request.session['cart'] = {}
        return redirect('canteen:order_status', order_id=order.id)
    return redirect('canteen:cart')

@login_required
def order_status(request, order_id):
    order = get_object_or_404(Order, pk=order_id, user=request.user)
    return render(request, 'canteen/order_status.html', {'order': order})

@login_required
def staff_dashboard(request):
    if request.user.role != CustomUser.STAFF:
        return HttpResponse('Forbidden', status=403)
    orders = Order.objects.exclude(status=Order.COMPLETED).order_by('timeslot', 'created_at')
    if request.method == 'POST':
        oid = request.POST.get('order_id')
        new_status = request.POST.get('status')
        o = get_object_or_404(Order, pk=oid)
        if new_status in dict(Order.STATUS_CHOICES):
            o.status = new_status
            o.save()
    return render(request, 'canteen/staff_dashboard.html', {'orders': orders})
